Smart Digital Marketing Services — Neon Blue Edition

Files:
- index.html: complete responsive website (HTML, CSS and JavaScript)
- assets/smart-digital-logo.png: logo
- assets/homepage-banner.jpg: homepage hero banner
- assets/neon-hero-banner.jpg: alternate banner asset
- assets/services-design-reference.png: approved design reference preview

How to run:
1. Extract the ZIP file.
2. Keep the assets folder beside index.html.
3. Open index.html in Chrome or another modern browser.

The Services section has been redesigned in a neon-blue 12-card layout. About, Customer Reviews, Packages, Contact and Footer copy/sections from the existing website are retained. WhatsApp service buttons open a prefilled chat to 01774749768.
